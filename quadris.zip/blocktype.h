#ifndef _BLOCKTYPE_H_
#define _BLOCKTYPE_H_
enum class BlockType {I, J, L, O, S, Z, T, L4, N, Hint};
#endif
