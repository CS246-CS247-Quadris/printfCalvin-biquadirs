#include <sstream>
#include "quadris.h"
#include <fstream>


using namespace std;

int main(int argc, const char * argv[]) {
    Quadris q;
    q.play(argc, argv);
}
