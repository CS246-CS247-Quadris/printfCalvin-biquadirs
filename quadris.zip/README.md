cs246 Quadris project in a group of 3 
