#ifndef __INFO_H__
#define __INFO_H__
#include "blocktype.h"

struct Info {
    int row, col;
    BlockType type;
};

#endif
